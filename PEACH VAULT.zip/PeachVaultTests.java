package com.peachvault;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Automation tests for https://peachvault.com (WooCommerce/Elementor store).
 *
 * Safe by design: never places an order and never creates an account.
 *
 * Run:  mvn clean test
 * Headless:  mvn clean test -Dheadless=true
 */
public class PeachVaultTests {

    private static final String BASE = "https://peachvault.com";

    // Product ID taken from the homepage "Add to cart" link (?add-to-cart=3647).
    // If this product goes out of stock or is removed, change it to another simple product ID.
    private static final String SIMPLE_PRODUCT_ID = "3647";
    private static final String SIMPLE_PRODUCT_SLUG = "haute-sauce-pink";

    private WebDriver driver;
    private WebDriverWait wait;

    // ------------------------------------------------------------------ setup / teardown

    @BeforeMethod
    public void setUp() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--window-size=1366,900", "--disable-notifications");
        if (Boolean.getBoolean("headless")) {
            options.addArguments("--headless=new");
        }
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        if (driver != null) {
            if (result.getStatus() == ITestResult.FAILURE) {
                takeScreenshot(result.getName());
            }
            driver.quit();
        }
    }

    // ------------------------------------------------------------------ 1. home page

    @Test(description = "Home page loads with correct title and logo")
    public void homePageLoads() {
        driver.get(BASE + "/");
        Assert.assertTrue(driver.getTitle().toLowerCase().contains("peachvault"),
                "Unexpected title: " + driver.getTitle());
        Assert.assertFalse(driver.findElements(By.cssSelector("a[href='https://peachvault.com/'] img")).isEmpty(),
                "Logo not found");
    }

    @Test(description = "All top-level menu categories are present in the header")
    public void mainMenuHasAllTopLevelCategories() {
        driver.get(BASE + "/");
        String[] menuPaths = {
                "/product-category/topwear/",
                "/product-category/bottom-wear/",
                "/product-category/dresses/",
                "/product-category/accecories/",
                "/product-category/jewelleryy/",
                "/product-category/kids/",
                "/product-category/best-sellers/"
        };
        for (String path : menuPaths) {
            Assert.assertFalse(driver.findElements(By.cssSelector("a[href$='" + path + "']")).isEmpty(),
                    "Menu link missing: " + path);
        }
    }

    @Test(description = "Home page shows products with prices and add-to-cart links")
    public void homePageShowsProducts() {
        driver.get(BASE + "/");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href*='/product/']")));
        Assert.assertTrue(driver.findElements(By.cssSelector("h2 a[href*='/product/']")).size() >= 5,
                "Expected several products on the home page");
        Assert.assertFalse(driver.findElements(By.cssSelector("a[href*='add-to-cart=']")).isEmpty(),
                "No add-to-cart links found");
        Assert.assertTrue(driver.getPageSource().contains("₹"), "No rupee prices found");
    }

    @Test(description = "Footer shows the store's contact details")
    public void footerContactDetailsVisible() {
        driver.get(BASE + "/");
        String source = driver.getPageSource().toLowerCase();
        Assert.assertTrue(source.contains("peachvaultclothing@gmail.com"), "Contact email missing");
        Assert.assertTrue(source.contains("92079 70127"), "Contact phone missing");
        Assert.assertTrue(source.contains("changanacherry"), "Address missing");
    }

    // ------------------------------------------------------------------ 2. every page in the menu

    @DataProvider(name = "pages")
    public Object[][] pages() {
        String[] paths = {
                "/shop/", "/about-us/", "/journal/", "/wishlist/", "/my-account/",
                // Topwear
                "/product-category/topwear/",
                "/product-category/women/ready-to-wear/tops/",
                "/product-category/women/ready-to-wear/shirts/",
                "/product-category/topwear/tshirts/",
                "/product-category/topwear/jackets/",
                "/product-category/topwear/hoodies/",
                "/product-category/topwear/shortkurtis/",
                "/product-category/topwear/winterwear/",
                // Bottom wear
                "/product-category/bottom-wear/",
                "/product-category/bottom-wear/jeans/",
                "/product-category/bottom-wear/formal-pants/",
                "/product-category/bottom-wear/shorts/",
                "/product-category/bottom-wear/skirts/",
                "/product-category/bottom-wear/joggers/",
                "/product-category/bottom-wear/cargos/",
                // Dresses
                "/product-category/dresses/",
                "/product-category/dresses/casualwear/",
                "/product-category/dresses/partywear/",
                // Accessories
                "/product-category/accecories/",
                "/product-category/women/accessories/bags/",
                "/product-category/women/accessories/belt/",
                "/product-category/women/accessories/socks/",
                "/product-category/women/ready-to-wear/lingerie/",
                // Jewellery
                "/product-category/jewelleryy/",
                "/product-category/jewelleryy/rings/",
                "/product-category/jewelleryy/earrings/",
                "/product-category/jewelleryy/bracelets/",
                "/product-category/jewelleryy/necklaces/",
                // Kids
                "/product-category/kids/",
                "/product-category/kids/girlsclothing/",
                "/product-category/kids/boysclothing/",
                "/product-category/kids/newborn/",
                "/product-category/kids/babyaccessories/",
                "/product-category/kids/toys/",
                // Best sellers
                "/product-category/best-sellers/"
        };
        Object[][] data = new Object[paths.length][1];
        for (int i = 0; i < paths.length; i++) {
            data[i][0] = paths[i];
        }
        return data;
    }

    @Test(dataProvider = "pages", description = "Every menu/footer page loads without an error")
    public void pageLoadsWithoutError(String path) {
        String url = BASE + path;
        int status = getStatus(url);
        Assert.assertTrue(status > 0 && status < 400, "HTTP " + status + " for " + url);

        driver.get(url);
        String title = driver.getTitle().toLowerCase();
        Assert.assertFalse(title.contains("not found") || title.contains("404"),
                "Error page title '" + driver.getTitle() + "' for " + url);
    }

    @Test(description = "No broken internal links on the home page")
    public void noBrokenInternalLinksOnHomePage() {
        driver.get(BASE + "/");
        Set<String> links = new LinkedHashSet<>();
        for (WebElement a : driver.findElements(By.tagName("a"))) {
            String href = a.getAttribute("href");
            if (href == null || !href.startsWith(BASE)) continue;
            if (href.contains("#") || href.contains("add-to-cart") || href.contains("logout")) continue;
            links.add(href);
        }
        Assert.assertFalse(links.isEmpty(), "No internal links found");

        List<String> broken = new ArrayList<>();
        for (String link : links) {
            int status = getStatus(link);
            if (status < 0 || status >= 400) {
                broken.add(status + " -> " + link);
            }
        }
        Assert.assertTrue(broken.isEmpty(), "Broken links:\n" + String.join("\n", broken));
    }

    // ------------------------------------------------------------------ 3. shop, product, search

    @Test(description = "Shop page lists products")
    public void shopPageListsProducts() {
        driver.get(BASE + "/shop/");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href*='/product/']")));
        Assert.assertFalse(driver.findElements(By.cssSelector("a[href*='/product/']")).isEmpty());
    }

    @Test(description = "Product detail page opens from the home page and shows name + price")
    public void productDetailPageOpensFromHome() {
        driver.get(BASE + "/");
        WebElement link = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("h2 a[href*='/product/']")));
        String href = link.getAttribute("href");
        driver.get(href);

        Assert.assertTrue(driver.getCurrentUrl().contains("/product/"), "Not on a product page");
        WebElement heading = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("h1")));
        Assert.assertFalse(heading.getAttribute("textContent").trim().isEmpty(), "Product name is empty");
        Assert.assertFalse(driver.findElements(By.cssSelector(".price, .woocommerce-Price-amount")).isEmpty(),
                "Price not shown");
    }

    @Test(description = "Product search returns relevant results")
    public void searchReturnsResults() {
        // URL-based search is more reliable than clicking the header search icon.
        driver.get(BASE + "/?s=jacket&post_type=product");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("a[href*='/product/']")));
        Assert.assertTrue(driver.getPageSource().toLowerCase().contains("jacket"),
                "Search results do not mention 'jacket'");
    }

    @Test(description = "Search for nonsense shows no products")
    public void searchWithNoMatchShowsNothing() {
        driver.get(BASE + "/?s=zzzxqwv123&post_type=product");
        String text = driver.findElement(By.tagName("body")).getText().toLowerCase();
        Assert.assertTrue(text.contains("no products") || text.contains("nothing found")
                        || text.contains("no results") || text.contains("not found"),
                "Expected a 'no results' message");
    }

    // ------------------------------------------------------------------ 4. cart & checkout (no order placed)

    @Test(description = "Add a product to the cart and see it on the cart page")
    public void addToCartShowsItemInCart() {
        driver.get(BASE + "/?add-to-cart=" + SIMPLE_PRODUCT_ID);
        driver.get(BASE + "/cart/");
        wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("a[href*='" + SIMPLE_PRODUCT_SLUG + "']")));
    }

    @Test(description = "Remove an item from the cart leaves it empty")
    public void removeItemFromCart() {
        driver.get(BASE + "/?add-to-cart=" + SIMPLE_PRODUCT_ID);
        driver.get(BASE + "/cart/");
        WebElement remove = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.remove")));
        remove.click();
        wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector(".cart-empty, .wc-empty-cart-message")));
    }

    @Test(description = "Checkout page shows billing form (form is NOT submitted)")
    public void checkoutPageShowsBillingForm() {
        driver.get(BASE + "/?add-to-cart=" + SIMPLE_PRODUCT_ID);
        driver.get(BASE + "/checkout/");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("billing_first_name")));
        Assert.assertFalse(driver.findElements(By.id("billing_phone")).isEmpty(), "Phone field missing");
        Assert.assertFalse(driver.findElements(By.id("billing_email")).isEmpty(), "Email field missing");
    }

    // ------------------------------------------------------------------ 5. login

    @Test(description = "Login with wrong credentials shows an error")
    public void loginWithInvalidCredentialsShowsError() {
        driver.get(BASE + "/my-account/");
        firstDisplayed(By.cssSelector("input#username")).sendKeys("not.a.real.user@example.com");
        firstDisplayed(By.cssSelector("input#password")).sendKeys("WrongPassword!123");
        firstDisplayed(By.cssSelector("button[name='login']")).click();

        WebElement error = firstDisplayed(By.cssSelector(".woocommerce-error"));
        Assert.assertTrue(error.getText().toLowerCase().contains("error"),
                "Unexpected message: " + error.getText());
    }

    @Test(description = "Login with empty fields is blocked")
    public void loginWithEmptyFieldsIsBlocked() {
        driver.get(BASE + "/my-account/");
        WebElement user = firstDisplayed(By.cssSelector("input#username"));
        WebElement button = firstDisplayed(By.cssSelector("button[name='login']"));

        // If the field is 'required', the browser blocks the submit itself.
        boolean blockedByBrowser = (Boolean) ((JavascriptExecutor) driver)
                .executeScript("return arguments[0].validity.valueMissing;", user);
        button.click();

        if (blockedByBrowser) {
            Assert.assertTrue(driver.getCurrentUrl().contains("my-account"), "Left the login page");
        } else {
            firstDisplayed(By.cssSelector(".woocommerce-error"));
        }
    }

    // ------------------------------------------------------------------ 6. responsive

    @Test(description = "Mobile viewport: home page has no horizontal scroll")
    public void mobileViewHasNoHorizontalScroll() {
        driver.manage().window().setSize(new Dimension(390, 844));
        driver.get(BASE + "/");
        wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));

        JavascriptExecutor js = (JavascriptExecutor) driver;
        long scrollWidth = (Long) js.executeScript("return document.documentElement.scrollWidth;");
        long clientWidth = (Long) js.executeScript("return document.documentElement.clientWidth;");
        Assert.assertTrue(scrollWidth <= clientWidth + 5,
                "Horizontal overflow: scrollWidth=" + scrollWidth + " clientWidth=" + clientWidth);
    }

    // ------------------------------------------------------------------ helpers

    /** The site renders a login popup on every page, so ids like #username can appear twice. Pick the visible one. */
    private WebElement firstDisplayed(By by) {
        return wait.until(d -> d.findElements(by).stream()
                .filter(WebElement::isDisplayed)
                .findFirst()
                .orElse(null));
    }

    private int getStatus(String url) {
        try {
            int code = request(url, "HEAD");
            if (code >= 400) {
                code = request(url, "GET"); // some servers reject HEAD
            }
            return code;
        } catch (IOException e) {
            return -1;
        }
    }

    private int request(String url, String method) throws IOException {
        HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(10_000);
        c.setReadTimeout(15_000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Selenium link checker)");
        int code = c.getResponseCode();
        c.disconnect();
        return code;
    }

    private void takeScreenshot(String testName) {
        try {
            Path dir = Paths.get("target", "screenshots");
            Files.createDirectories(dir);
            byte[] png = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            Files.write(dir.resolve(testName + "-" + System.currentTimeMillis() + ".png"), png);
        } catch (Exception ignored) {
            // screenshot is best-effort
        }
    }
}
